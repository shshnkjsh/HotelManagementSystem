USE [HotelManagementSystem]
GO

/****** Object:  Table [dbo].[fact_master_details]    Script Date: 6/20/2022 10:55:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fact_master_details](
	[MasterId] [int] IDENTITY(1,1) NOT NULL,
	[MasterUserName] [varchar](255) NOT NULL,
	[MasterPassword] [varchar](255) NULL,
	[Role] [varchar](10) NOT NULL,
	[InsertionDate] [datetime] NULL,
	[TotalRoom] [int] NULL,
	[AvailableRoom] [int] NULL,
	[TotalAcRoom] [int] NULL,
	[AvailableAcRoom] [int] NULL,
	[TotalSingleBedAcRoom] [int] NULL,
	[AvailableSingleBedAcRoom] [int] NULL,
	[SingleBedAcRoomPrice] [int] NULL,
	[TotalDoubleBedAcRoom] [int] NULL,
	[AvailableDoubleBedAcRoom] [int] NULL,
	[DoubleBedAcRoomPrice] [int] NULL,
	[TotalNonAcRoom] [int] NULL,
	[AvailableNonAcRoom] [int] NULL,
	[TotalSingleBedNonAcRoom] [int] NULL,
	[AvailableSingleBedNonAcRoom] [int] NULL,
	[SingleBedNonAcRoomPrice] [int] NULL,
	[TotalDoubleBedNonAcRoom] [int] NULL,
	[AvailableDoubleBedNonAcRoom] [int] NULL,
	[DoubleBedNonAcRoomPrice] [int] NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[MasterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT (getdate()) FOR [InsertionDate]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalSingleBedAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableSingleBedAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [SingleBedAcRoomPrice]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalDoubleBedAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableDoubleBedAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [DoubleBedAcRoomPrice]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalNonAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableNonAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalSingleBedNonAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableSingleBedNonAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [SingleBedNonAcRoomPrice]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [TotalDoubleBedNonAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [AvailableDoubleBedNonAcRoom]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((0)) FOR [DoubleBedNonAcRoomPrice]
GO

ALTER TABLE [dbo].[fact_master_details] ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[fact_master_details]  WITH CHECK ADD CHECK  (([Role]='master'))
GO


/* Insert Master Data, Note : Insert Only One Time */

insert into fact_master_details(MasterUserName,MasterPassword,Role) values ('India','India@123','master')
