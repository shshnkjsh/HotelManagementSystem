USE [HotelManagementSystem]
GO

/****** Object:  Table [dbo].[UserDetail]    Script Date: 6/20/2022 10:56:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserDetail](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](255) NULL,
	[PassWord] [varchar](255) NULL,
	[Role] [varchar](10) NOT NULL,
	[InsertionDate] [varchar](255) NULL,
	[IsActive] [bit] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[UserDetail] ADD  DEFAULT (getdate()) FOR [InsertionDate]
GO

ALTER TABLE [dbo].[UserDetail] ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[UserDetail]  WITH CHECK ADD CHECK  (([Role]='manager' OR [Role]='customer' OR [Role]='master'))
GO


Insert Into UserDetail (UserName, PassWord, Role) values ('India', 'India@123', 'master')