USE [HotelManagementSystem]
GO

/****** Object:  Table [dbo].[CustomerDetails]    Script Date: 6/20/2022 10:54:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerDetails](
	[CustomerID] [int] IDENTITY(1,1) NOT NULL,
	[InsertionDate] [varchar](50) NULL,
	[RoomType] [varchar](50) NOT NULL,
	[RoomScenerio] [varchar](50) NOT NULL,
	[RoomPrice] [int] NOT NULL,
	[CustomerName] [varchar](255) NULL,
	[Contact] [varchar](10) NULL,
	[EmailID] [varchar](255) NULL,
	[Address] [varchar](511) NULL,
	[Age] [int] NULL,
	[CheckInTime] [varchar](50) NULL,
	[CheckOutTime] [varchar](50) NULL,
	[IDProof] [varchar](50) NULL,
	[IDNumber] [varchar](100) NULL,
	[PinCode] [varchar](10) NULL,
	[IsActive] [bit] NULL,
	[IsPaid] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (getdate()) FOR [InsertionDate]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [CustomerName]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [Contact]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [EmailID]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [Address]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT ((0)) FOR [Age]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [CheckInTime]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [CheckOutTime]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [IDProof]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT (NULL) FOR [IDNumber]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[CustomerDetails] ADD  DEFAULT ((0)) FOR [IsPaid]
GO


