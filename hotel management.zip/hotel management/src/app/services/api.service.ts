import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }
  getMasterDate() {
    return this.http.get(environment.apiBaseUrl + "/api/Admin/GetMasterData");
  }
  setMasterDate(payload:any) {
    return this.http.post(environment.apiBaseUrl + "/api/Admin/InsertMasterData",payload);
  }
  bookroom(payload:any){
    return this.http.post(environment.apiBaseUrl + "/api/User/InsertCustomerDetail",payload);

  }
  update(payload:any){
    return this.http.put(environment.apiBaseUrl + "/api/User/UpdateCustomerDetail", payload);

  }
  deletep(payload:any){
    return this.http.delete(environment.apiBaseUrl + "/api/User/DeleteCustomerDetail?customerId="+payload);

  }
  pay(payload:any){
    return this.http.patch(environment.apiBaseUrl + "/api/User/PayCustomerBill", payload);
 
  }
  post(url: string, payload: any) {
    return this.http.post(environment.apiBaseUrl + url, payload);
  }
  patch(url: string, payload: any) {
    return this.http.patch(environment.apiBaseUrl + url, payload);
  }
  delete(url: string, payload?: any) {
    if (!payload) {
      return this.http.delete(environment.apiBaseUrl + url);
    }
    return this.http.delete(environment.apiBaseUrl + url, {
      body: payload
    });
  }

}
