import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from '../services/alert/alert.service';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-book-room',
  templateUrl: './book-room.component.html',
  styleUrls: ['./book-room.component.scss']
})
export class BookRoomComponent implements OnInit {
  roomType: any;
  roomScenerio: any;
  roomPrice: any;
  customerName: any;
  contact: any;
  emailID: any;
  address: any;
  age: any;
  checkInTime: any;
  checkOutTime: any;
  idProof: any;
  idNumber: any;
  pinCode: any;
  checkOutTime1: any;
  checkInTime1: any;
  obj: any;
  editFlag: any;

  constructor(private router:Router,
    private api:ApiService,
  private alert:AlertService) { }

  ngOnInit(): void {
     this.editFlag=JSON.parse(sessionStorage.getItem('editFlag')||'false');
 
  if(this.editFlag==true){
    this.obj=JSON.parse(sessionStorage.getItem('editObj')||'false');
    this.roomType= this.obj.roomType;
  this.roomScenerio= this.obj.roomScenerio;

  this.roomPrice= this.obj.roomPrice;

  this.customerName= this.obj.customerName;

  this.contact= this.obj.contact;

  this.emailID= this.obj.emailID;

  this.address= this.obj.address;

  this.age= this.obj.age;

  this.checkInTime= this.obj.checkInTime;

  this.checkOutTime= this.obj.checkOutTime;

  this.idProof= this.obj.idProof;

  this.idNumber= this.obj.idNumber;

  this.pinCode= this.obj.pinCode;
 
  }else{
    this.roomType=sessionStorage.getItem('type');
    this.roomScenerio=sessionStorage.getItem('scenario');
    this.roomPrice=sessionStorage.getItem('price');
  }
  }
  insuranceType(e:any){
    this.idProof=e.target.value;
  }
  changeDate(){
    let day=1;
    if(this.checkInTime&&this.checkOutTime){
      this.checkOutTime1 = new Date(this.checkOutTime);
      this.checkInTime1 = new Date(this.checkInTime);


    day=  Math.floor((Date.UTC(this.checkOutTime1.getFullYear(), this.checkOutTime1.getMonth(), this.checkOutTime1.getDate()) - Date.UTC(this.checkInTime1.getFullYear(), this.checkInTime1.getMonth(), this.checkInTime1.getDate()) ) /(1000 * 60 * 60 * 24));
    if(day>1)
    this.roomPrice=day*this.roomPrice;
  }
}
  book(){
    var x = Number(this.roomPrice)
    var y = String(this.contact)
    var z = String(this.age)
    var p = String(this.pinCode)
    var i = String(this.idNumber)
  if(this.editFlag){
    
    this.api.update({ 
      customerID:this.obj.customerID,
      roomType: this.roomType,
      roomScenerio: this.roomScenerio,
      roomPrice: x,
      customerName:this.customerName,
      contact: y,
      emailID:this.emailID,
      address: this.address,
      age: z,
      checkInTime:this.checkInTime,
      checkOutTime: this.checkOutTime,
      idProof: this.idProof,
      idNumber: i,
      pinCode: p
        }).subscribe((res: any) => {
      
      if(res.isSuccess){
        this.router.navigate(['/my-booking']);
        this.alert.show({ title: "Success", message: 'Updated successfully', icon: 'success' });
         
      }
      }, this.alert.error());

  }
  else{
    this.api.bookroom({ roomType: this.roomType,
    roomScenerio: this.roomScenerio,
    roomPrice: x,
    customerName:this.customerName,
    contact: y,
    emailID:this.emailID,
    address: this.address,
    age: z,
    checkInTime:this.checkInTime,
    checkOutTime: this.checkOutTime,
    idProof: this.idProof,
    idNumber: i,
    pinCode: p
      }).subscribe((res: any) => {
    
    if(res.isSuccess){
      this.router.navigate(['/my-booking']);
      this.alert.show({ title: "Success", message: 'Room Booked successfully', icon: 'success' });
       
    }
    }, this.alert.error());

  }
  sessionStorage.setItem('editFlag', 'true');

  }
  
  cancel(){
      this.router.navigate(['/']);

  }
  
}


