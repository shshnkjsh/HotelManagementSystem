import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-setting',
  templateUrl: './customer-setting.component.html',
  styleUrls: ['./customer-setting.component.scss']
})
export class CustomerSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
