import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { AlertService } from 'src/app/services/alert/alert.service';
import { CartService, OrderListType } from 'src/app/services/cart/cart.service';
import { CustomerService } from 'src/app/services/customer/customer.service';

@Component({
  selector: 'app-my-order',
  templateUrl: './my-order.component.html',
  styleUrls: ['./my-order.component.scss']
})
export class MyOrderComponent implements OnInit {

  usersList = [];
  displayedColumns: string[] = ['userID', 'userName', 'fullName', 'emailID', 'mobileNumber'];
  allRecordsCount = 0;
  pageSize = 10;
  pageEvent: any;

  constructor(
    private customer: CustomerService
  ) { }

  ngOnInit(): void {
    this.getCustomerList(1);
  }

  getCustomerList(pageNumber: number) {
    this.customer.getAll({
      pageNumber,
      numberOfRecordPerPage: this.pageSize
    }).subscribe((res: any) => {
      this.usersList = res?.data ;
      this.allRecordsCount = res?.totalRecords;
    });
  }

  onPageChange(event: PageEvent) {
    this.getCustomerList(event.pageIndex + 1);
  }

}
