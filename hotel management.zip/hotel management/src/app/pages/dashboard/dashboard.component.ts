import { Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/services/alert/alert.service';
import { ApiService } from 'src/app/services/api.service';
import { CartService } from 'src/app/services/cart/cart.service';
import { ProductDataType, ProductService } from 'src/app/services/product/product.service';
import { SessionService } from 'src/app/services/storage/session.service';
import { WishlistService } from 'src/app/services/wishlist/wishlist.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  allRecordsCount = 0;
  pageSize = 12;
  pageEvent: any;
  view2: boolean=false;
  availableAcRoom: any;
  availableSingleBedAcRoom: any;
  singleBedAcRoomPrice: any;
  availableDoubleBedAcRoom: any;
  doubleBedAcRoomPrice: any;
  availableNonAcRoom: any;
  availableSingleBedNonAcRoom: any;
  availableDoubleBedNonAcRoom: any;
  doubleBedNonAcRoomPrice: any;
  view1: boolean=true;
  view3: boolean=false;
  singleBedNonAcRoomPrice: any;

  constructor(
    private api: ApiService,
    private wishlist: WishlistService,
    private cart: CartService,
    private session: SessionService,
    private alert: AlertService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.getData();  }
 
  
  getData() {
    this.api.getMasterDate().subscribe((res: any) => {
      //{"isSuccess":true,"message":"Successful","data":{"totalRoom":0,"availableRoom":0,"totalAcRoom":0,"availableAcRoom":0,"totalSingleBedAcRoom":0,
      //"availableSingleBedAcRoom":0,"singleBedAcRoomPrice":0,
      //"totalDoubleBedAcRoom":0,"availableDoubleBedAcRoom":0,"doubleBedAcRoomPrice":0,"totalNonAcRoom":0,
      //"availableNonAcRoom":0,"totalSingleBedNonAcRoom":0,"availableSingleBedNonAcRoom":0,
      //"singleBedNonAcRoomPrice":0,"totalDoubleBedNonAcRoom":0,"availableDoubleBedNonAcRoom":0,
      //"doubleBedNonAcRoomPrice":0}}
    if(res.isSuccess){
      this.availableAcRoom=res.data.availableAcRoom;
      this.availableSingleBedAcRoom=res.data.availableSingleBedAcRoom;
      this.singleBedAcRoomPrice=res.data.singleBedAcRoomPrice;
      this.availableDoubleBedAcRoom=res.data.availableDoubleBedAcRoom;
      this.doubleBedAcRoomPrice=res.data.doubleBedAcRoomPrice;
      this.availableNonAcRoom=res.data.availableNonAcRoom;
      this.availableSingleBedNonAcRoom=res.data.availableSingleBedNonAcRoom;
      this.availableDoubleBedNonAcRoom=res.data.availableDoubleBedNonAcRoom;
      this.doubleBedNonAcRoomPrice=res.data.doubleBedNonAcRoomPrice;
      this.singleBedNonAcRoomPrice=res.data.singleBedNonAcRoomPrice;


    }
    }, this.alert.error());
  }
  next(str:string){
  this.view1=false;
  if(str=='AC')
  this.view2=true;
  else
  this.view3=true;
  
  }
  book(type:string,scenario:string,price:string){
    sessionStorage.setItem('type', type);
    sessionStorage.setItem('scenario', scenario);
    sessionStorage.setItem('price', price);
     this.router.navigate(['/book'])

    // this.api.book({}).subscribe((res: any) => {
    //   if (res?.isSuccess) {
    //       this.router.navigate(['/'])

    //   } else {
    //     this.alert.show({ title: "Something went wrong", message: res?.message, icon: 'error' });
    //   }
    // }, err => {
    //   console.error(err);
    //   this.alert.show({ title: "Error", message: "API fail", icon: 'error' });
    // });

  }
  
}
