import { Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/services/alert/alert.service';
import { ApiService } from 'src/app/services/api.service';
import { CustomerDataType, CustomerService } from 'src/app/services/customer/customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent implements OnInit {
  usersList: CustomerDataType[] = [];
  displayedColumns: string[] = ['customerID', 'roomType', 'roomScenerio', 'roomPrice', 'customerName', 'contact', 'checkInTime', 'checkOutTime','status','action'];
  allRecordsCount = 0;
  pageSize = 10;
  pageEvent: any;
//"customerID": 2,
// "roomType": "Non-AC",
// "roomScenerio": "Double-Bed",
// "roomPrice": 9000,
// "customerName": "Aarati Kadu",
// "contact": "9527966348",
// "checkInTime": "2022-08-15",
// "checkOutTime": "2022-08-18",
// "isPaid": false
  constructor(
    private customer: CustomerService,
    private alert:AlertService,
    private api:ApiService,
    private router:Router,
  ) { }

  ngOnInit(): void {
    this.getCustomerList(1);
  }

  getCustomerList(pageNumber: number) {
    this.customer.getAll({
      pageNumber,
      numberOfRecordPerPage: this.pageSize
    }).subscribe((res: any) => {
      this.usersList = res?.data as CustomerDataType[];
      this.allRecordsCount = res?.totalRecords;
    });
  }
  edit(element:any){
    sessionStorage.setItem('editFlag', 'true');
    let product=element;
    //this.products.filter(p=>p.offerId===offerId);
    sessionStorage.setItem('editObj', JSON.stringify(product) );
    this.router.navigate(['book'])

  }
  delete(id:any){
    this.api.deletep(id).subscribe((res: any) => {
      if((res.isSuccess))
        this.alert.single('Successfully deleted booking.', 'success');
        this.getCustomerList(1);

    });

  }
  pay(id:any){
    
    this.api.pay({
      customerID:id
    }).subscribe((res: any) => {
      if((res.isSuccess))
      this.alert.single('Successfully Paid Bill.', 'success');
      this.getCustomerList(1);

    });
  }
  onPageChange(event: PageEvent) {
    this.getCustomerList(event.pageIndex + 1);
  }

}
