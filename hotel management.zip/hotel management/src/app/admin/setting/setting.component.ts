import { Component, OnInit } from '@angular/core';
import { AlertService } from 'src/app/services/alert/alert.service';
import { ApiService } from 'src/app/services/api.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss']
})
export class SettingComponent implements OnInit {
  totalRoom: any=0;
  totalAc: any=0;
  singleAc: any=0;
  singleAcPrice: any=0;
  doubleAc: any;
  doubleAcPrice: any=0;
  totalNonAc: any=0;
  singleNonAc: any=0;
  singleNonAcPrice: any=0;
  doubleNonAc: any=0;
  doubleNonAcPrice: any=0;

  constructor(private alert:AlertService,
              private api:ApiService,
              private router:Router) { }

  ngOnInit(): void {
  }
  
  ngDoCheck(): void {
    if(this.totalAc){
      this.totalNonAc=this.totalRoom-this.totalAc;
    }
    if(this.singleNonAc){
      this.doubleNonAc=this.totalNonAc-this.singleNonAc;
    }
    if(this.singleAc){
      this.doubleAc=this.totalAc-this.singleAc;
    }
  
  
  }
  
  changeData(){
    this.api.setMasterDate({ 
      totalRoom: this.totalRoom,
    totalAcRoom: this.totalAc,
    totalSingleBedAcRoom: this.singleAc,
    singleBedAcRoomPrice: this.singleAcPrice,
    totalDoubleBedAcRoom: this.doubleAc,
    doubleBedAcRoomPrice: this.doubleAcPrice,
    totalNonAcRoom: this.totalNonAc,
    totalSingleBedNonAcRoom: this.singleNonAc,
    singleBedNonAcRoomPrice: this.singleNonAcPrice,
    totalDoubleBedNonAcRoom: this.doubleNonAc,
    doubleBedNonAcRoomPrice: this.doubleNonAcPrice}).subscribe((res: any) => {
    
    if(res.isSuccess){
      this.router.navigate(['/setting']);
      this.alert.show({ title: "Success", message: 'Data Changed successfully', icon: 'success' });
       
    }
    }, this.alert.error());
  }
  
  cancel(){
      this.router.navigate(['/']);

  }
  
}
