export interface UserDetailsType {
    insertionDate: string;
    role: string;
    token: string;
    userId: number;
    userName: string
}