# EShopping

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.1.0.

## Setup
- First install packages using `npm instal`
- Update your Backend server address in `src/envirorment/envirorent.ts` file. 
```
export const environment = {
  production: false,
  apiBaseUrl: '<YOUR_BACKEND_API_URL>',
}
 ``` 

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.


## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

